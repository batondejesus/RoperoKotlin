package com.example.roperolistview

import android.widget.ImageView

data class Ropero(val nombre: String, val imagen: Int, val precio: Double ){
    companion object{
        val roperoSource = listOf(
            Ropero("Calcetin rojo", R.drawable.calcetin, 2.0),
            Ropero("Calcetin gris", R.drawable.calcetin1, 2.0),
            Ropero("Calcetin caballo", R.drawable.calcetin2, 2.0),
            Ropero("Calcetin azul largo", R.drawable.calcetin3, 3.0),
        )
    }
    override fun toString(): String {
        return nombre
    }
}

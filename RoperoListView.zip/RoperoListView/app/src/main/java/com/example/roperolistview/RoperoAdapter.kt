package com.example.roperolistview

import android.content.Context
import android.media.Image
import android.view.*
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import java.text.FieldPosition

class RoperoAdapter(context: Context, listaRopero: List<Ropero>) : ArrayAdapter<Ropero>(context,0,listaRopero) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val vista = convertView?: LayoutInflater.from(context).inflate(R.layout.ropero_esqueleto,parent,false)
        getItem(position)?.let { ropero ->
            vista.findViewById<TextView>(R.id.titulo_esqueleto).apply{
                text = ropero.nombre
            }
            vista.findViewById<ImageView>(R.id.imagen_esqueleto).apply {
                setImageResource(ropero.imagen)
            }
            vista.findViewById<TextView>(R.id.precio_esqueleto).apply {
                text = ropero.precio.toString()
            }
        }
        return vista
    }
}
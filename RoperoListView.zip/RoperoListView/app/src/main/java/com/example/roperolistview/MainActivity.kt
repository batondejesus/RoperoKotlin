package com.example.roperolistview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import com.example.roperolistview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var bind: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)

        RoperoAdapter(this,Ropero.roperoSource).also {
            roperoAdapter -> bind.ListView.adapter = roperoAdapter
        }

        bind.ListView.setOnItemClickListener(){ parent, view, position, l ->
            bind.textView.text = (parent.adapter.getItem(position) as Ropero).nombre
        }
        establecerPrecio()

    }

    fun establecerPrecio (){
        var rbs: RadioButton = findViewById<RadioButton>(R.id.rbS)
        val precio: TextView = findViewById<TextView>(R.id.precio_esqueleto)
        rbs.setOnClickListener(){
            precio.text = "Precio poco"
        }
    }
}